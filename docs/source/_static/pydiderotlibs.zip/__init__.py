"""
On désactive le message pygame.
"""
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
