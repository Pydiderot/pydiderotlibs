from .math_lycee import *
